/*
 * ***** BEGIN LICENSE BLOCK *****
 *
 * Zimbra Collaboration Suite CSharp Client
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.
 *
 * The contents of this file are subject to the Common Public Attribution License Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at: https://www.zimbra.com/license
 * The License is based on the Mozilla Public License Version 1.1 but Sections 14 and 15
 * have been added to cover use of software over a computer network and provide for limited attribution
 * for the Original Developer. In addition, Exhibit A has been modified to be consistent with Exhibit B.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.
 * See the License for the specific language governing rights and limitations under the License.
 * The Original Code is Zimbra Open Source Web Client.
 * The Initial Developer of the Original Code is Zimbra, Inc.  All rights to the Original Code were
 * transferred by Zimbra, Inc. to Synacor, Inc. on September 14, 2015.
 *
 * All portions of the code are Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc. All Rights Reserved.
 *
 * ***** END LICENSE BLOCK *****
 */
// Copyright (c) 2009-2012 Quadralay Corporation.  All rights reserved.
//

function WWHUnicode_Break_CheckBreak_Sequence(ParamPrevious,
                                              ParamCurrent)
{
  var  VarResult = true;

  if (
      (
       (ParamPrevious == " ")
      )
       &&
      (
       (true)
      )
     )
  {
    VarResult = false;
  }
  else if (
           (
            (true)
           )
            &&
           (
            (WWHUnicodeInfo_WWNoBreak(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_WWNoBreak(ParamPrevious))
           )
            &&
           (
            (true)
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Korean_L(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Korean_L(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Korean_L(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_LV(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Korean_LV(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Korean_L(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_LV(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Korean_V(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Korean_L(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Korean_LVT(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Korean_L(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_LV(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_V(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_LVT(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_T(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Korean_T(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_ALetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_ABaseLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_ACMLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_Numeric(ParamPrevious))
             ||
            (WWHUnicodeInfo_MidNum(ParamPrevious))
             ||
            (WWHUnicodeInfo_MidNumLet(ParamPrevious))
             ||
            (WWHUnicodeInfo_MidLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_Katakana(ParamPrevious))
             ||
            (WWHUnicodeInfo_Hiragana(ParamPrevious))
             ||
            (WWHUnicodeInfo_Ideographic(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_L(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_LV(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_V(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_LVT(ParamPrevious))
             ||
            (WWHUnicodeInfo_Korean_T(ParamPrevious))
             ||
            (WWHUnicodeInfo_Extend(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Extend(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_ALetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_Extend(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_ALetter(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Katakana(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Katakana(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Numeric(ParamPrevious))
             ||
            (WWHUnicodeInfo_MidNumLet(ParamPrevious))
             ||
            (WWHUnicodeInfo_MidLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_Extend(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_ABaseLetter(ParamCurrent))
             ||
            (WWHUnicodeInfo_ACMLetter(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_ALetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_ABaseLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_ACMLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_Extend(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_MidNumLet(ParamCurrent))
             ||
            (WWHUnicodeInfo_MidLetter(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_ABaseLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_ACMLetter(ParamPrevious))
             ||
            (WWHUnicodeInfo_MidNum(ParamPrevious))
             ||
            (WWHUnicodeInfo_MidNumLet(ParamPrevious))
             ||
            (WWHUnicodeInfo_Numeric(ParamPrevious))
             ||
            (WWHUnicodeInfo_Extend(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_Numeric(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_Numeric(ParamPrevious))
             ||
            (WWHUnicodeInfo_Extend(ParamPrevious))
           )
            &&
           (
            (WWHUnicodeInfo_MidNum(ParamCurrent))
             ||
            (WWHUnicodeInfo_MidNumLet(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (true)
           )
            &&
           (
            (WWHUnicodeInfo_Hiragana(ParamCurrent))
             ||
            (WWHUnicodeInfo_Ideographic(ParamCurrent))
           )
          )
  {
    VarResult = true;
  }
  else if (
           (
            (true)
           )
            &&
           (
            (WWHUnicodeInfo_WWCloseBracket(ParamCurrent))
           )
          )
  {
    VarResult = false;
  }
  else if (
           (
            (WWHUnicodeInfo_WWOpenBracket(ParamPrevious))
           )
            &&
           (
            (true)
           )
          )
  {
    VarResult = false;
  }

  return VarResult;
}

function WWHUnicode_CheckBreakAtIndex(ParamString,
                                      ParamIndex)
{
  var  VarResult = false;

  if (ParamIndex < ParamString.length)
  {
    if (ParamString.length == 1)
    {
      VarResult = false;
    }
    else if (ParamString.length > 1)
    {
      // String is at least two characters long
      //
      if (ParamIndex == 0)
      {
        VarResult = false;
      }
      else
      {
        var  VarPrevious = ParamString.charAt(ParamIndex - 1);
        var  VarCurrent = ParamString.charAt(ParamIndex);

        VarResult = WWHUnicode_Break_CheckBreak_Sequence(VarPrevious, VarCurrent);

        // Check ending
        //
        if ( ! VarResult)
        {
          // Ending with a middle character?
          //
          if (
              (WWHUnicodeInfo_MidLetter(VarCurrent))
               ||
              (WWHUnicodeInfo_MidNumLet(VarCurrent))
               ||
              (WWHUnicodeInfo_MidNum(VarCurrent))
             )
          {
            // Check next character
            //
            if ((ParamIndex + 1) == ParamString.length)
            {
              // Break at end of search string
              //
              VarResult = true;
            }
            else
            {
              var  VarNext = ParamString.charAt(ParamIndex + 1);

              // Depends on the next character
              //
              VarResult = WWHUnicode_Break_CheckBreak_Sequence(VarCurrent, VarNext);
            }
          }
        }
      }
    }
  }

  return VarResult;
}
